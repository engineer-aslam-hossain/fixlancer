import FilterdFix from "../FilterdFix/FilterdFix";

const LandingPage = () => {
  return (
    <section>
      <FilterdFix />
    </section>
  );
};

export default LandingPage;
