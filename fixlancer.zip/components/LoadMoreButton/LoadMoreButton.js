import classes from "./LoadMoreButton.module.scss";
const LoadMoreButton = () => {
  return <button className={classes.more_btn}>Load More</button>;
};

export default LoadMoreButton;
