export const dummy_notifications = [
  {
    img: "/images/author.jpg",
    text: "Nibh senectus ut et egestas ornare. Molestie pulvinar rutrum turpis turpis mauris. Vitae amet sed fames vel sit est sociis gravida in. ",
    time: "7:30am",
  },
  {
    img: "/images/author1.png",
    text: "Nibh senectus ut et egestas ornare. Molestie pulvinar rutrum turpis turpis mauris. Vitae amet sed fames vel sit est sociis gravida in. ",
    time: "7:30am",
  },
  {
    img: "/images/author2.png",
    text: "Nibh senectus ut et egestas ornare. Molestie pulvinar rutrum turpis turpis mauris. Vitae amet sed fames vel sit est sociis gravida in. ",
    time: "7:30am",
  },
  {
    img: "/images/author3.png",
    text: "Nibh senectus ut et egestas ornare. Molestie pulvinar rutrum turpis turpis mauris. Vitae amet sed fames vel sit est sociis gravida in. ",
    time: "7:30am",
  },
  {
    img: "/images/author4.png",
    text: "Nibh senectus ut et egestas ornare. Molestie pulvinar rutrum turpis turpis mauris. Vitae amet sed fames vel sit est sociis gravida in. ",
    time: "7:30am",
  },
  {
    img: "/images/author5.png",
    text: "Nibh senectus ut et egestas ornare. Molestie pulvinar rutrum turpis turpis mauris. Vitae amet sed fames vel sit est sociis gravida in. ",
    time: "7:30am",
  },
];
