export const dummy_persons = [
  {
    username: "dev_aslam",
    description:
      "I am a graphics designer with more than 2yrs of experience. Clients satisfaction is a top priority to me. You can contact me anytime. I am always...",
    img: "/images/author.jpg",
    chat: [
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:33:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:37:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost",
        time: "2022/01/28 15:39:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three",
        time: "2022/01/28 15:42:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:45:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost fsadf  fsadf sf  fas fs d  fsa",
        time: "2022/01/28 15:49:12",
      },
      {
        by: "me",
        msg: "Good morning, brother kemon acho tumi",
        time: "2022/01/28 15:59:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost",
        time: "2022/01/28 15:39:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three",
        time: "2022/01/28 15:42:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:45:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost fsadf  fsadf sf  fas fs d  fsa",
        time: "2022/01/28 15:49:12",
      },
      {
        by: "me",
        msg: "Good morning, brother kemon acho tumi",
        time: "2022/01/28 15:59:12",
      },
    ],
  },
  {
    username: "rafin_biswas",
    description:
      "I am a graphics designer with more than 2yrs of experience. Clients satisfaction is a top priority to me. You can contact me anytime. I am always...",
    img: "/images/author1.png",
    chat: [
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:33:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:37:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost",
        time: "2022/01/28 15:39:12",
      },
    ],
  },
  {
    username: "sahanaz_akter",
    description:
      "I am a graphics designer with more than 2yrs of experience. Clients satisfaction is a top priority to me. You can contact me anytime. I am always...",
    img: "/images/author2.png",
    chat: [
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:33:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:37:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost",
        time: "2022/01/28 15:39:12",
      },
    ],
  },
  {
    username: "radovandanley",
    description:
      "I am a graphics designer with more than 2yrs of experience. Clients satisfaction is a top priority to me. You can contact me anytime. I am always...",
    img: "/images/author4.png",
    chat: [
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:33:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:37:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost",
        time: "2022/01/28 15:39:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three",
        time: "2022/01/28 15:42:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:45:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost fsadf  fsadf sf  fas fs d  fsa",
        time: "2022/01/28 15:49:12",
      },
      {
        by: "me",
        msg: "Good morning, brother kemon acho tumi",
        time: "2022/01/28 15:59:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost",
        time: "2022/01/28 15:39:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost my telegram channel in three",
        time: "2022/01/28 15:42:12",
      },
      {
        by: "me",
        msg: "Good morning, I want to boost my telegram channel in three weeks to help sponsor my new single I would be releasing",
        time: "2022/01/28 15:45:12",
      },
      {
        by: "him",
        msg: "Good morning, I want to boost fsadf  fsadf sf  fas fs d  fsa",
        time: "2022/01/28 15:49:12",
      },
      {
        by: "me",
        msg: "Good morning, brother kemon acho tumi",
        time: "2022/01/28 15:59:12",
      },
    ],
  },
];
