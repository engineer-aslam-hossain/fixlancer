module.exports = {
  images: {
    domains: ["http://purecatamphetamine.github.io"],
  },
};
